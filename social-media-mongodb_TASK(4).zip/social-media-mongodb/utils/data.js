const users = [
    { username: "sarah", email: "sarah@mail.com"},
    { username: "luke_skywalker", email: "lukeskywalker@mail.com"},
    { username: "bryan02", email: "bryan@mail.com"},
    { username: "jimmyjohns", email: "jimmyjohns@mail.com"}
];

module.exports = users;